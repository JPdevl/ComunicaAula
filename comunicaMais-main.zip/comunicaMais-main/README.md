# comunica-aula
Projeto de prancha digital de CAA para estudantes
bora lá...
Realizei a modularização do nosso projeto,criei pastas para uma melhor organização e para não ficar repetindo varias linhas de codigo html implementei o js.

Descrição doq foi feito: Na pasta js temos: /Componentes; /Paginas;  inicio.js e app.js
componentes possui cartoes.js