export function criarCartao({id, classe, icone, titulo, descricao, pagina}) 
{
    const cartao = document.createElement("button");

    cartao.className = `cartao ${classe}`;
    cartao.id = id;

    cartao.innerHTML = `
        <div class="cartao-icone">
            <span class="emoji">${icone}</span>
        </div>

        <div class="cartao-texto">
            <h2>${titulo}</h2>
            <p>${descricao}</p>
        </div>

        <div class="cartao-seta">›</div>
    `;

    cartao.addEventListener("click", () => {
        window.location.href = pagina;
    });

    return cartao;
}