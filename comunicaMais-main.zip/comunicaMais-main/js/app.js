import { carregarInicio } from "./paginas/inicio.js";

document.addEventListener("DOMContentLoaded", () => {
    carregarInicio();
});
