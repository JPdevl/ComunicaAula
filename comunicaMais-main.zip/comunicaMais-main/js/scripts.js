const botoes = document.querySelectorAll(".cartao");

botoes.forEach((botao) => {
    botao.addEventListener("click", () => {
        const texto = botao.querySelector("h2").textContent;

        const fala = new SpeechSynthesisUtterance(texto);
        fala.lang = "pt-BR";
        fala.rate = 0.9;
        fala.pitch = 1;

        speechSynthesis.cancel();
        speechSynthesis.speak(fala);
    });
});

const formularioComunicador = document.getElementById("form-comunicador");

if (formularioComunicador) {
    formularioComunicador.addEventListener("submit", (evento) => {
        evento.preventDefault();

        const campoTexto = document.getElementById("texto-comunicador");
        const texto = campoTexto.value.trim();

        if (!texto) {
            campoTexto.focus();
            return;
        }

        const fala = new SpeechSynthesisUtterance(texto);
        fala.lang = "pt-BR";
        fala.rate = 0.9;
        fala.pitch = 1;

        speechSynthesis.cancel();
        speechSynthesis.speak(fala);
    });
}