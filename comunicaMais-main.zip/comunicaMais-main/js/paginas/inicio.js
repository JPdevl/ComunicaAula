import {criarCartao} from "../componentes/cartoes.js"

const categorias = [
    {
        id: "btn-participar",
        classe: "card-verde",
        icone:"🙋",
        titulo:"Participar",
        descricao: "Quero participar da aula",
        pagina: "paginas/participar.html"
    },
    {
        id:"btn-duvidas",
        classe: "card-azul",
        icone: "❓",
        titulo: "Dúvidas",
        descricao:"Tenho dúvidas",
        pagina : "paginas/duvidas.html"
    },
    {
        id: "btn-necessidades",
        classe: "card-amarelo",
        icone: "🆘",
        titulo: "Necessidades",
        descricao: "Preciso comunicar uma necessidade",
        pagina: "paginas/necessidades.html"
    }
    
];
export function carregarInicio() {
    const lista = document.querySelector("#lista-categorias");

        categorias.forEach(categoria => {
            const cartao = criarCartao(categoria);

            lista.appendChild(cartao);
        });
}
